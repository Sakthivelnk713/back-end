package com.niit.model;

public class Chat {

}
