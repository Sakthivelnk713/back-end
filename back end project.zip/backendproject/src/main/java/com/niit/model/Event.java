package com.niit.model;

public class Event {

}
