package com.niit.model;

public class Friend {
	
	@Id
	private int id;
	@Column(name="user_id")
	private String userID;
	@Column(name="friend_id")
	private String friendID;
	 
	private String status;
	
	
	public String getStatus() {
		
	}

}
