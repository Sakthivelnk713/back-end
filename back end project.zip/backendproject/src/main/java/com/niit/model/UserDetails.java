package com.niit.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "C_USER_DETAIL")
@Component

public class UserDetails {
	
	
	

	@Id
	private String id;
	
	private String name;
	
	private String email;
	
	private String address;
	
	private String mobile;

	private String password;
	
	@Transient
	private char userType;
	
	
	@OneToMany(mappedBy="userDetails",fetch = FetchType.EAGER)
	private Set<UserRole> userRoles;
	
	public Set<UserRole> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(Set<UserRole> userRoles) {
		this.userRoles = userRoles;
	}
	}
