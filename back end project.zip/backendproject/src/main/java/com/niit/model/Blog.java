package com.niit.model;

public class Blog {

}
