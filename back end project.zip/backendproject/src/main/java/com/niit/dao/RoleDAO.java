package com.niit.dao;

import java.util.List;

import com.niit.model.Role;

public interface RoleDAO {
	public List<Role> list();

	public Role get(String id, String password);

	public Role get(String id);

	public boolean save(Role role);

	public boolean update(Role role);

	public void delete(String id);

	public boolean isValidRole(String id, String name);

}
