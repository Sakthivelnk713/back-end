package com.niit.dao;

public interface JobDAO {

}
