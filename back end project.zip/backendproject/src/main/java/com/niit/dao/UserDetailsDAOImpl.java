package com.niit.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.UserDetails;
@Repository
public class UserDetailsDAOImpl implements UserDetailsDAO {
	public static final Logger Log = LoggerFactory.getLogger(UserDetailsDAOImpl.class);
	 
	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private UserDetails userDetails;
	
	public UserDetailsDAOImpl(SessionFactory sessionFactory) {
	try  {
		this.sessionFactory = sessionFactory;
	}   catch(Exception e)  {
		Log.error(" Unable to connect to db");
		e.printStackTrace();
	}
		
	}
	
	public UserDetailsDAOImpl()
	{
		
	}
	
	@Transactional
	
	public List<UserDetails> list() {
		String hql = "from UserDetails";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		 
		 
		 @SuppressWarnings("unchecked")
		List<UserDetails>  list = (List <UserDetails>) query.list();
		 
		 return list;
		 
	}
	
	@Transactional
	
	public boolean saveOrUpdate(UserDetails userDetails) {
		 
		try {
			
			
			 sessionFactory.getCurrentSession().saveOrUpdate(userDetails);
			return true; 
		} catch(HibernateException e) {
			
			//TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
			
		}
	
	
	
@Transactional
	
	public boolean delete(String id) {
		 
		try {
			
			
			 sessionFactory.getCurrentSession().delete(userDetails);
			return true; 
		} catch(Exception e) {
			
			//TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
		return true;
		
		
		}
@SuppressWarnings("unchecked")
@Transactional
public UserDetails get(String id)  {
	
	String hql = "from UserDetails where id=" + "'" + id + "'";
	
	Query query = sessionFactory.getCurrentSession().createQuery(hql);

	
	List<UserDetails> list = (List<UserDetails>) query.list();
	
	if(list !=  null && !list.isEmpty()) {
		
		return list.get(0);
		
	}
	return null;
	

}
