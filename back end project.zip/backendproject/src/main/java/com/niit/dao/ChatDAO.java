package com.niit.dao;

import java.util.List;

import com.niit.model.Chat;

public interface ChatDAO {
	public List<Chat> list();

	

	public Chat get(String id);

	public boolean saveOrUpdate(Chat chat);


	public void delete(String id);


}
