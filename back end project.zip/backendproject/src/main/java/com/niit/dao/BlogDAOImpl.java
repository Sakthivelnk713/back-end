package com.niit.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Blog;

@Repository("blogDAO")
public class BlogDAOImpl implements BlogDAO{
	public static final Logger Log = LoggerFactory.getLogger(UserDetailsDAOImpl.class);
	 
	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private Blog blog;
	
	public BlogDAOImpl(SessionFactory sessionFactory) {
	try  {
		this.sessionFactory = sessionFactory;
	}   catch(Exception e)  {
		Log.error(" Unable to connect to db");
		e.printStackTrace();
	}
		
	}
	
	public BlogDAOImpl()
	{
		
	}
	
	@Transactional
	
	public List<Blog> list() {
		String hql = "from Blog";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		 
		 
		 @SuppressWarnings("unchecked")
		List<Blog>  list = (List <Blog>) query.list();
		 
		 return list;
		 
	}
	
	@Transactional
	
	public boolean saveOrUpdate(Blog blog) {
		 
		try {
			
			
			 sessionFactory.getCurrentSession().saveOrUpdate(blog);
			return true; 
		} catch(HibernateException e) {
			
			//TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
			
		}
	
	
	
@Transactional
	
	public boolean delete(String id) {
		 
		try {
			
			
			 sessionFactory.getCurrentSession().delete(blog);
			return true; 
		} catch(Exception e) {
			
			//TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
		return true;
		
		
		}
@SuppressWarnings("unchecked")
@Transactional
public Blog get(String id)  {
	
	String hql = "from Blog where id=" + "'" + id + "'";
	
	Query query = sessionFactory.getCurrentSession().createQuery(hql);

	
	List<Blog> list = (List<Blog>) query.list();
	
	if(list !=  null && !list.isEmpty()) {
		
		return list.get(0);
		
	}
	return null;
	
}
	