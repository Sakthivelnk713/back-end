package com.niit.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.User;

@Repository

public class UserDAOImpl implements UserDAO {
	public static final Logger Log = LoggerFactory.getLogger(UserDAOImpl.class);
	 
	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private User user;
	
	public UserDAOImpl(SessionFactory sessionFactory) {
	try  {
		this.sessionFactory = sessionFactory;
	}   catch(Exception e)  {
		Log.error(" Unable to connect to db");
		e.printStackTrace();
	}
		
	}
	
	public UserDAOImpl()
	{
		
	}
	
	@Transactional
	
	public List<User> list() {
		String hql = "from User";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		 
		 
		 @SuppressWarnings("unchecked")
		List<User>  list = (List <User>) query.list();
		 
		 return list;
		 
	}
	
	@Transactional
	
	public boolean saveOrUpdate(User user) {
		 
		try {
			
			
			 sessionFactory.getCurrentSession().saveOrUpdate(user);
			return true; 
		} catch(HibernateException e) {
			
			//TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
			
		}
	
	
	
@Transactional
	
	public boolean delete(String id) {
		 
		try {
			
			
			 sessionFactory.getCurrentSession().delete(user);
			return true; 
		} catch(Exception e) {
			
			//TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
		return true;
		
		
		}
@SuppressWarnings("unchecked")
@Transactional
public User get(String id)  {
	
	String hql = "from User where id=" + "'" + id + "'";
	
	Query query = sessionFactory.getCurrentSession().createQuery(hql);

	
	List<User> list = (List<User>) query.list();
	
	if(list !=  null && !list.isEmpty()) {
		
		return list.get(0);
		
	}
	return null;
	

}
