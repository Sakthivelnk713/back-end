package com.niit.dao;

	import java.util.List;

	import com.niit.model.Friend;

	public interface  FriendDAO{
		
		
		
		public List<Friend> list();
		
		
		
		public List<Friend> get(String userID);

		public Friend get(String userID, String friendID);


		public boolean saveOrUpdate(Friend friend);

		public void delete(String userID, String friendID);

		

	}


