package com.niit.dao;

public interface EventDAO {

}
