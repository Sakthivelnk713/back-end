package com.niit.Config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.embedded.ConnectionProperties;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@ComponentScan("com.niit")
@EnableTransactionManagement
public class ApplicationContextConfig {

	@Bean(name = "datasource")
	public DataSource getOracleDataSource() {
		DriverManagerDataSource datasource = new DriverManagerDataSource();
		dataSource.setDriverClassName("");
		dataSource.setUrl("");
		
		dataSource.setUsername("");
		dataSource.setPassword("");
		
		Properties connectionProperties = new Properties();
		ConnectionProperties.setProperty("hibernate.hbm2ddl.auto", "update");
		ConnectionProperties.setProperty("hibernate.show_sql", "true");
		ConnectionProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle11gDialect");
		ConnectionProperties.setProperty("hibernate.format_sql", "true");
		ConnectionProperties.setProperty("hibernate.jdbc.use_get_generated_keys", "true");
		//ConnectionProperties.setProperty("hibernate.default_schema", "");
		dataSource.setConnectionProperties(ConnectionProperties);
		return dataSource;
	}
	private Properties getHibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.show_sql", "true");
		// properties.put("hibernate.dialect",
		// "org.hibernate.dialect.MySQLDialect");
		
		properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		return properties;
					
	}
	
	@Autowired
	@Bean(name = "sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource) {
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder();
		sessionBuilder.addProperties(getHibernateProperties());
		sessionBuilder.addAnnotatedClass(User.class);
		return sessionBuilder.buildSessionFactory();
		
	}
	
	
	@Autowired
	@Bean(name = "transactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory)
	HibernateTransactionManager gettransactionManager = new HibernateTransactionManager
	
	return transactionManager;
	
}
