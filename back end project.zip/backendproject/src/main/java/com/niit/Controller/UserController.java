package com.niit.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.niit.dao.UserDAO;






@RestController
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);



	@Autowired
	UserDAO userDAO;



	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public ResponseEntity<List<User>> listAllUsers() {
		logger.debug("->->->->calling method listAllUsers");
		List<User> User = userDAO.list();
		if (User.isEmpty()) {
		
			return new ResponseEntity<List<User>>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<List<User>>(HttpStatus.NOT_FOUND);

		}
		return new ResponseEntity<List<User>>(user, HttpStatus.OK);
	}
	
	
	
@RequestMapping(value = "/user/", method = RequestMethod.POST)
public ResponseEntity<User> createUser(@RequestBody User user) {
	logger.debug("->->->->calling method createUser");
	if (userDAO.get(user.getID()) == null) {
		userDAO.save(user);

		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	logger.debug("->->->->User already exist with the id :"+ user.getId());
     return new ResponseEntity<User>(User, HttpStatus.CONFLICT);
}



@RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
public ResponseEntity<User> updateUser(@PathVariable("id") String id, @RequestBody User user) {
logger.debug("->->->->calling method updateUser");
if (userDAO.get(id) == null) {
	logger.debug("->->->->User does not exist with the id :"+ user.getId());
	return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
}
userDAO.update(user);

logger.debug("->->->->User updated successfully");
 return new ResponseEntity<User>(user, HttpStatus.OK);
}

@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
public ResponseEntity<User> deleteUser(@PathVariable("id") String id) {
logger.debug("->->->->calling method deleteUser");
User user = userDAO.get(id);
if (user == null) {
	logger.debug("->->->->User does not exist with the id");
	return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
}
userDAO.detele(user);

logger.debug("->->->->User deletedsuccessfully");
 return new ResponseEntity<User>(user, HttpStatus.OK);
}


