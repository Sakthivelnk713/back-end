package com.niit.Controller;

import org.jboss.logging.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

@RestController

public class BlogController {
	private static final Logger logger = LoggerFactory.getLogger(BlogController.class);

	@Autowired
	private BlogDAO blogDao;

	@Autowired
	private Blog blog;

	@GetMapping("/blogs")
	public ResponseEntity<List<Blog>> getBlogs() {
		logger.debug("calling method getBlogs");
		List<Blog> list = blogDAO.list();
		if (list.isEmpty()) {
			return new ResponseEntity<List<Blog>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Blog>>(HttpStatus.OK);
	}

	@GetMapping("/blogs/{id}")
	public ResponseEntity<List<Blog>> getBlogs(@PathVariable("id") String id) {
		logger.debug("calling method getBlogs with the id" + id);
		blog = blogDAO.get(id);
		if (blog == null) {

			return new ResponseEntity<Blog>(HttpStatus.NO_FOUND);
		}
		return new ResponseEntity<Blog>(HttpStatus.OK);
	}

	@PostMapping(value = "/blog")
	public ResponseEntity<Blog> createBlog(@RequestBody Blog blog) {
		logger.debug("calling method createBlog");
		blogDAO.saveOrUpdate(blog);
		return new ResponseEntity<Blog>(blog, HttpStatus.OK);

	}

	@DeleteMapping("/blogs/{id}")
	public ResponseEntity<Blog> deleteBlog(@PathVariable String id) {
		logger.debug("calling method deleteBlog with the id" + id);

		if (blogDAO.get(id) == null) {

			return new ResponseEntity<Blog>(HttpStatus.NO_FOUND);
		}
		blogDAO.delete(id);
		return new ResponseEntity<Blog>(HttpStatus.OK);
	}

	@PutMapping("/blogs/{id}")
	public ResponseEntity<Blog> updateBlog(@PathVariable String id, @RequestBody Blog blog) {
		logger.debug("calling method updateBlog with the id" + id);
	
		if (blogDAO.get(id)==null) {

			return new ResponseEntity<Blog>(HttpStatus.NO_FOUND);
		}
		blogDAO.saveOrUpdate(id);
		return new ResponseEntity<Blog>(HttpStatus.OK);
	}
