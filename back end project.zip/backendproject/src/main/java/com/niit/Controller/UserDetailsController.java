package com.niit.Controller;



import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.niit.dao.UserDetailsDAO;
import com.niit.model.Role;
import com.niit.model.UserDetails;
import com.niit.model.UserRole;

@RestController
public class UserDetailsController {

	private static final Logger logger = LoggerFactory.getLogger(UserDetailsController.class);

	@Autowired
	UserDetails userDetails;

	@Autowired
	UserDetailsDAO userDetailsDAO;

	@Autowired
	UserRole userRole;
	
	@Autowired
	Role role;

	@GetMapping("/UserDetails/")
	public ResponseEntity<List<UserDetails>> listAllUserDetailss() {
		logger.debug("calling method listAllUserDetailss");
		List<UserDetails> userDetails = userDetailsDAO.list();
		if (userDetails.isEmpty()) {
			logger.debug("NO Users are available");
			return new ResponseEntity<List<Blog>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Blog>>(HttpStatus.OK);
	}
@GetMapping("/UserDetails/{id}")
public ResponseEntity<UserDetails> getUserDetails(@RequestParam("id") String id) {
	logger.debug("calling method getUserDetails");
	UserDetails UserDetails = userDetailsDAO.get(id);
	if (UserDetails == null) {

		return new ResponseEntity<UserDetails>(HttpStatus.NO_FOUND);
	}
	return new ResponseEntity<UserDetails>(UserDetails, HttpStatus.OK);
}
@PostMapping(value = "/UserDetails")
public ResponseEntity<void> createUserDetails((@RequestBody UserDetails userDetails, UriComponentuilder ucBuilder) {
	logger.debug("calling method createUserDetails");
	if(userDetailsDAO.get(userDetails.getId()) != null) {
		logger.debug("User exists with the id :"+ userDetails.getId());
		return new ResponsesEntity<void>(HttpStatus.CONFLICT);
	}
	role.setId("ROLE_USER");
	role.setName("ROLE_USER");
	userRole.setId("ROLE_USER");
	userRole.setRole("role");
	Set<UserRole> userRoles = new HashSet<UserRole><>;
	userRoles.add(userRole);
	userDetails.setUserRoles(userRoles);
	userDetailsDAO.save(userDetails);
	
	HttpHeaders headers = new HttpHeaders();
	headers.setLocation(ucBuilber.path("/UserDetails/{id}").buildAndExpand(userDetails.getId()).to;
	logger.debug("Ending method createUserDetails");
	return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
}
